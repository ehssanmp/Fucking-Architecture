package simulator.gates.sequential.flipflops;

public interface FlipFlop {
    void setOutput();
    void loadMemory();
}
