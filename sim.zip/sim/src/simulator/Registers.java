package simulator;


import simulator.gates.combinational.Memory;
import simulator.gates.sequential.Clock;
import simulator.network.Link;
import simulator.wrapper.wrappers.Register;


public class Registers {
	static Register [] Reg= new Register[32];
	
	
}
