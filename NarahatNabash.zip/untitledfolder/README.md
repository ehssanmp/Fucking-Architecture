# GraphBasedMinimalistCircuitSimulator
Graph-Based Minimalist Circuit Simulator Dedicated to Goli
